# -*- coding: utf-8 -*-
import odoo

from odoo import http, models, fields, _
from odoo.http import request
import json

class LatihanController(http.Controller):

    @http.route('/sale')
    def get_sale(self, **kwargs):
        value = {
            'order_id': 'S0001',
            'customer': 'Agus Budianto',
            'total': 4000000
        }
        return json.dumps(value)
